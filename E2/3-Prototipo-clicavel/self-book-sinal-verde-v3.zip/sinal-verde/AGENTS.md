# Architecture
- Keep booking data in a shared in-memory SchoolProvider for this presentation prototype; no real authentication, storage or instructor notifications are implied.
- Use separate TanStack routes for login, booking and booked lessons, with SchoolLayout shared by the two lesson pages.
- Define instructor colors as semantic scoped CSS variables and use the shared instructor registry so every view keeps the same instructor identity.
- Instructors and their weekly shifts live in SchoolProvider state (seeded from lesson-data) so the admin page (/bastidores) edits flow straight into booking availability.
- Each instructor carries school, status (trabalhando/ferias/baixa), code, car and join date; the admin page has two views (Gerir horários per school, Ver instrutores roster) and booking only offers instructors with status trabalhando.
