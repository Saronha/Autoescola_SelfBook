# Sinal Verde — protótipo de escola de condução

Protótipo de demonstração de uma escola de condução: página de entrada, marcação de
aulas, lista de aulas marcadas e uma área de administração ("Bastidores") para gerir
horários e instrutores de várias escolas.

Sem autenticação real e sem base de dados: tudo vive em memória durante a sessão.

## Como executar

Requer [bun](https://bun.sh) (ou npm).

```bash
bun install
bun run dev
```

Abre depois `http://localhost:8080`.

Para correr os testes das regras de marcação:

```bash
bun run test
```

## Páginas

| Caminho         | O que é                                                              |
| --------------- | -------------------------------------------------------------------- |
| `/`             | Entrada — "Entrar com Google", explorar a escola, explorar bastidores |
| `/marcar-aulas` | Calendário de marcação com horários por instrutor                    |
| `/aulas`        | Lista das aulas já marcadas                                          |
| `/bastidores`   | Administração: gerir horários e ver instrutores                      |

## Onde está o quê

- `src/lib/lesson-data.ts` — dados de exemplo (escolas, instrutores, turnos,
  horários livres) e todas as regras de marcação e cancelamento.
- `src/lib/lesson-data.test.ts` — testes automáticos dessas regras.
- `src/components/SchoolContext.tsx` — estado partilhado (aulas e instrutores).
- `src/components/LessonCalendar.tsx` — calendário, cores dos instrutores e janela
  de detalhes de uma aula.
- `src/routes/bastidores.tsx` — área de administração.
- `src/styles.css` — paleta, tipos de letra e estilos partilhados.

## Regras de marcação

- Máximo 4 aulas por dia e 2 aulas seguidas uma da outra.
- Só há 6 aulas práticas obrigatórias por marcar; depois disso não se marca mais.
- Não se marcam aulas para dias que já passaram (o "hoje" do protótipo é 12/10/2026).
- Só aulas práticas têm calendário; os outros tipos mostram uma mensagem.
- Aulas do próprio dia não se podem desmarcar; o cancelamento avisa das 24 horas.

## Cores dos instrutores

Cada instrutor tem uma cor guardada como variável CSS com o seu código
(`--ic-abrao`, `--ic-bete`, ...). A cor aparece nos botões de marcação, nas aulas
da agenda e na tabela de horários, e é atribuída automaticamente a um instrutor
novo a partir da lista em `INSTRUCTOR_COLORS` (em `src/lib/lesson-data.ts`).
