# Driving school redesign
- [x] Recreate login, lesson booking, booked lessons and confirmation layouts with a playful traffic palette.
- [x] Verify the complete demonstration booking flow and page layouts.
- [x] Apply required package security update.