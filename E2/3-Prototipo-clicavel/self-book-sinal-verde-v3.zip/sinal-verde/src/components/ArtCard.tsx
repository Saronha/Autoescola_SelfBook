import type { Artwork } from "@/lib/artworks";

export function ArtCard({ art }: { art: Artwork }) {
  const h = Math.round(280 * art.ratio);
  const gradient =
    art.hue === 140
      ? `linear-gradient(135deg, oklch(0.7 0.09 140), oklch(0.55 0.08 340))`
      : `linear-gradient(135deg, oklch(0.75 0.07 340), oklch(0.6 0.08 140))`;
  return (
    <figure className="group break-inside-avoid mb-4 overflow-hidden rounded-xl border border-border bg-card shadow-sm hover:shadow-soft transition-all duration-500">
      <div
        className="w-full relative overflow-hidden"
        style={{ height: h, background: gradient }}
      >
        <div className="absolute inset-0 opacity-40 mix-blend-overlay"
          style={{
            backgroundImage:
              "radial-gradient(circle at 30% 30%, white, transparent 50%), radial-gradient(circle at 70% 70%, black, transparent 60%)",
          }}
        />
        <div className="absolute inset-0 flex items-end p-4 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-t from-black/60 to-transparent">
          <div className="text-white">
            <p className="font-display text-lg">{art.title}</p>
            <p className="text-xs opacity-80">{art.medium} · {art.year}</p>
          </div>
        </div>
      </div>
    </figure>
  );
}
