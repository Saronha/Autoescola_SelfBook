export function PageHeader({ eyebrow, title, description }: { eyebrow?: string; title: string; description?: string }) {
  return (
    <header className="max-w-4xl mx-auto px-6 pt-16 pb-10 text-center">
      {eyebrow && (
        <p className="text-xs uppercase tracking-[0.25em] text-primary mb-4">{eyebrow}</p>
      )}
      <h1 className="font-display text-5xl md:text-6xl font-bold leading-tight text-gradient">
        {title}
      </h1>
      {description && (
        <p className="mt-5 text-lg text-muted-foreground max-w-2xl mx-auto">{description}</p>
      )}
    </header>
  );
}
