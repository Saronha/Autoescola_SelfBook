export function SchoolBrand(){return <div className="brand"><span className="traffic-logo" aria-hidden="true"><i/><i/><i/></span><span>sinal verde<small>Escola de condução</small></span></div>}
