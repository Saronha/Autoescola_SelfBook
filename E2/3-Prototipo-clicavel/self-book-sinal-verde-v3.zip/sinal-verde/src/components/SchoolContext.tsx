import {createContext,useContext,useState,type ReactNode} from 'react';
import {initialLessons,instructors as initialInstructors,type Lesson,type Instructor} from '@/lib/lesson-data';
type Ctx={lessons:Lesson[];addLesson:(l:Lesson)=>void;removeLesson:(id:string)=>void;instructors:Instructor[];addInstructor:(i:Instructor)=>void;removeInstructor:(id:string)=>void;updateInstructor:(i:Instructor)=>void};
const SchoolContext=createContext<Ctx|null>(null);
export function SchoolProvider({children}:{children:ReactNode}){const[lessons,setLessons]=useState(initialLessons);const[instructors,setInstructors]=useState(initialInstructors);return <SchoolContext.Provider value={{lessons,addLesson:lesson=>setLessons(old=>[...old,lesson]),removeLesson:id=>setLessons(old=>old.filter(l=>l.id!==id)),instructors,addInstructor:i=>setInstructors(o=>[...o,i]),removeInstructor:id=>setInstructors(o=>o.filter(i=>i.id!==id)),updateInstructor:i=>setInstructors(o=>o.map(x=>x.id===i.id?i:x))}}>{children}</SchoolContext.Provider>}
export function useSchool(){const context=useContext(SchoolContext);if(!context)throw new Error('School provider missing');return context;}
