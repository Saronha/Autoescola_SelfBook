// Placeholder gallery data using gradient SVGs as colorful blocks.
// Replace src with real artwork URLs anytime.
export type Artwork = {
  id: string;
  title: string;
  year: string;
  medium: string;
  ratio: number; // height / width for masonry sizing
  hue: number;
};

const make = (n: number): Artwork[] =>
  Array.from({ length: n }, (_, i) => ({
    id: `art-${i + 1}`,
    title: [
      "Floresta de Vidro", "Eco do Musgo", "Lavanda Selvagem", "Cogumelo Roxo",
      "Sereia de Pântano", "Retrato em Bruma", "Sonho de Samambaia", "Ametista Viva",
      "Bosque Encantado", "Caracol Lunar", "Fada do Lodo", "Líquen Dourado",
    ][i % 12],
    year: ["2023", "2024", "2025"][i % 3],
    medium: ["Digital", "Aquarela", "Procreate", "Mixed media"][i % 4],
    ratio: [1.2, 0.8, 1.4, 1.0, 1.3, 0.9, 1.1, 1.5][i % 8],
    hue: i % 2 === 0 ? 140 : 340,
  }));

export const artworks = make(12);
