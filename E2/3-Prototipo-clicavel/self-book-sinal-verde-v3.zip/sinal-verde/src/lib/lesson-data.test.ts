import {describe,it,expect} from 'vitest';
import {bookingError,canCancel,isWorking,instructors,SCHOOLS,DAILY_LIMIT_MSG,CONSECUTIVE_MSG,ALL_BOOKED_MSG,PAST_DATE_MSG,type Lesson} from './lesson-data';
const L=(hour:number,date='2026-10-13'):Lesson=>({id:String(hour)+date,date,hour,instructor:'abrao',type:'Aulas práticas'});
describe('booking rules',()=>{
 it('blocks a fifth lesson on the same day',()=>{const ls=[L(8),L(10),L(12),L(14)];expect(bookingError(ls,'2026-10-13',16)).toBe(DAILY_LIMIT_MSG);expect(bookingError(ls.slice(0,3),'2026-10-13',16)).toBeNull();});
 it('blocks a third consecutive lesson',()=>{const ls=[L(8),L(9)];expect(bookingError(ls,'2026-10-13',10)).toBe(CONSECUTIVE_MSG);expect(bookingError(ls,'2026-10-13',7)).toBe(CONSECUTIVE_MSG);expect(bookingError([L(8),L(10)],'2026-10-13',9)).toBe(CONSECUTIVE_MSG);expect(bookingError(ls,'2026-10-13',11)).toBeNull();});
 it('cannot cancel lessons on the current day',()=>{expect(canCancel(L(15,'2026-10-12'),'2026-10-12')).toBe(false);expect(canCancel(L(15,'2026-10-13'),'2026-10-12')).toBe(true);});
 it('blocks booking after the 6 remaining lessons are booked',()=>{const five=[L(8),L(10),L(8,'2026-10-14'),L(10,'2026-10-14'),L(8,'2026-10-15')];expect(bookingError(five,'2026-10-16',8)).toBeNull();expect(bookingError([...five,L(8,'2026-10-16')],'2026-10-17',8)).toBe(ALL_BOOKED_MSG);});
 it('blocks booking for days that already passed',()=>{expect(bookingError([],'2026-10-11',8)).toBe(PAST_DATE_MSG);expect(bookingError([],'2026-10-01',10)).toBe(PAST_DATE_MSG);expect(bookingError([],'2026-10-12',8)).toBeNull();});
});
import {workHours} from './lesson-data';
describe('instructor shifts',()=>{
 it('morning shift 7h-16h with 1h pause gives 8 hours',()=>{const w=workHours({shift:'manha',pause:12});expect(w.length).toBe(8);expect(w).toContain(7);expect(w).not.toContain(12);expect(w).not.toContain(16);});
 it('afternoon shift 11h-20h with 1h pause gives 8 hours',()=>{const w=workHours({shift:'tarde',pause:15});expect(w.length).toBe(8);expect(w).toContain(19);expect(w).not.toContain(20);expect(w).not.toContain(10);});
 it('day off has no hours',()=>{expect(workHours({shift:'folga',pause:0})).toEqual([]);});
});
describe('instructor roster',()=>{
 it('every instructor belongs to a known school and has a code, car and join date',()=>{for(const i of instructors){expect(SCHOOLS).toContain(i.school);expect(i.code).toMatch(/^\d{3}$/);expect(i.car.length).toBeGreaterThan(0);expect(i.joined).toMatch(/^\d{4}-\d{2}-\d{2}$/);}});
 it('only working instructors can take bookings',()=>{expect(isWorking({...instructors[0],status:'trabalhando'})).toBe(true);expect(isWorking({...instructors[0],status:'ferias'})).toBe(false);expect(isWorking({...instructors[0],status:'baixa'})).toBe(false);});
});
