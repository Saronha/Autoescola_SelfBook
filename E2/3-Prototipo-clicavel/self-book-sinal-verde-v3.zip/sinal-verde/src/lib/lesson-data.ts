export type Shift='manha'|'tarde'|'folga';
export type DaySchedule={shift:Shift;pause:number};
export type InstructorStatus='trabalhando'|'ferias'|'baixa';
export type Instructor={id:string;code:string;name:string;initials:string;color:string;school:string;status:InstructorStatus;car:string;joined:string;schedule:DaySchedule[]};
export const SCHOOLS=['Carregado','Vila Franca','Alenquer','Alverca'];
export const DEFAULT_SCHOOL='Carregado';
export const STATUS_LABELS:Record<InstructorStatus,string>={trabalhando:'A trabalhar',ferias:'Férias',baixa:'Baixa médica'};
export const WEEKDAYS=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
export const SHIFTS:Record<Exclude<Shift,'folga'>,{label:string;start:number;end:number}>={manha:{label:'Manhã',start:7,end:16},tarde:{label:'Tarde',start:11,end:20}};
export const INSTRUCTOR_COLORS=['instructor-green','instructor-blue','instructor-orange','instructor-pink','instructor-purple','instructor-teal','instructor-red','instructor-brown'];
export function pauseOptions(shift:Shift){if(shift==='folga')return [];const s=SHIFTS[shift];return Array.from({length:s.end-s.start-2},(_,i)=>s.start+1+i);}
export function defaultPause(shift:Shift){return shift==='manha'?12:shift==='tarde'?15:0;}
export function week(shift:Shift,offDay=-1):DaySchedule[]{return Array.from({length:6},(_,i)=>{const sh=i===offDay?'folga':shift;return {shift:sh,pause:defaultPause(sh)}});}
export function workHours(day:DaySchedule):number[]{if(day.shift==='folga')return [];const s=SHIFTS[day.shift];return Array.from({length:s.end-s.start},(_,i)=>s.start+i).filter(h=>h!==day.pause);}
export function initialsOf(name:string){return name.trim().split(/\s+/).map(w=>w[0]).slice(0,2).join('').toUpperCase()||'?';}
export function isWorking(i:Instructor){return i.status==='trabalhando';}
export const instructors:Instructor[] = [
 { id:'abrao', code:'001', name:'Abrão Abreu', initials:'AA', color:'instructor-green', school:'Carregado', status:'trabalhando', car:'AB-45-12', joined:'2007-04-19', schedule:week('manha',2) },
 { id:'bete', code:'002', name:'Bete Betume', initials:'BB', color:'instructor-blue', school:'Vila Franca', status:'ferias', car:'CD-68-89', joined:'2012-05-04', schedule:week('tarde',0) },
 { id:'cida', code:'003', name:'Cida Cirilo', initials:'CC', color:'instructor-orange', school:'Alverca', status:'baixa', car:'EF-78-45', joined:'2024-10-10', schedule:week('manha',5) },
 { id:'dora', code:'004', name:'Dora Douro', initials:'DD', color:'instructor-pink', school:'Carregado', status:'trabalhando', car:'GH-17-89', joined:'2026-02-24', schedule:week('tarde',3) },
];
export type Lesson = {id:string; date:string; hour:number; instructor:string; type:string};
export const initialLessons:Lesson[]=[
 {id:'1',date:'2026-10-12',hour:8,instructor:'abrao',type:'Aulas práticas'},
 {id:'2',date:'2026-10-13',hour:10,instructor:'abrao',type:'Aulas práticas'},
 {id:'3',date:'2026-10-13',hour:15,instructor:'bete',type:'Aulas práticas'},
 {id:'4',date:'2026-10-16',hour:12,instructor:'cida',type:'Aulas práticas'},
 {id:'5',date:'2026-10-16',hour:13,instructor:'cida',type:'Aulas práticas'},
];
export const MAX_DAILY_LESSONS=4;
export const MAX_CONSECUTIVE_LESSONS=2;
export const TODAY='2026-10-12';
export const DAILY_LIMIT_MSG='só podes marcar no máximo 4 aulas no mesmo dia!';
export const CONSECUTIVE_MSG='só podes ter no máximo 2 aulas seguidas uma da outra!';
export const MIN_BOOKABLE_DATE=TODAY;
export const PAST_DATE_MSG='não podes marcar aulas para dias que já passaram!';
export const REMAINING_REQUIRED_LESSONS=6;
export const ALL_BOOKED_MSG='já marcaste todas as aulas obrigatórias';
export function bookingError(lessons:Lesson[],date:string,hour:number):string|null{if(date<MIN_BOOKABLE_DATE)return PAST_DATE_MSG;if(lessons.filter(l=>l.type==='Aulas práticas').length>=REMAINING_REQUIRED_LESSONS)return ALL_BOOKED_MSG;const day=lessons.filter(l=>l.date===date);if(day.some(l=>l.hour===hour))return 'Este horário já está ocupado.';if(day.length>=MAX_DAILY_LESSONS)return DAILY_LIMIT_MSG;const hours=new Set(day.map(l=>l.hour));let run=1;for(let h=hour-1;hours.has(h);h--)run++;for(let h=hour+1;hours.has(h);h++)run++;if(run>MAX_CONSECUTIVE_LESSONS)return CONSECUTIVE_MSG;return null;}
export function canBook(lessons:Lesson[],date:string,hour:number){return bookingError(lessons,date,hour)===null;}
export function canCancel(lesson:Lesson,today:string=TODAY){return lesson.date>today;}
export function isAvailable(instructor:Instructor|undefined,dayIndex:number,hour:number){const d=instructor?.schedule[dayIndex];return !!d&&workHours(d).includes(hour);}
export function dateKey(date:Date){return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;}
