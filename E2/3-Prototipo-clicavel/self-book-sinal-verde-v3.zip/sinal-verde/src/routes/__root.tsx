import {QueryClient,QueryClientProvider} from '@tanstack/react-query';
import {Outlet,createRootRouteWithContext,HeadContent,Scripts,Link} from '@tanstack/react-router';
import {SchoolProvider} from '@/components/SchoolContext';
import appCss from '../styles.css?url';
export const Route=createRootRouteWithContext<{queryClient:QueryClient}>()({head:()=>({meta:[{charSet:'utf-8'},{name:'viewport',content:'width=device-width, initial-scale=1'}],links:[{rel:'stylesheet',href:appCss},{rel:'preconnect',href:'https://fonts.googleapis.com'},{rel:'preconnect',href:'https://fonts.gstatic.com',crossOrigin:'anonymous'},{rel:'stylesheet',href:'https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Nunito:wght@400;500;600;700;800;900&display=swap'}]}),shellComponent:RootShell,component:RootComponent,notFoundComponent:()=> <div className="p-12 text-center"><h1 className="text-3xl mb-5">Este caminho não existe.</h1><Link to="/" className="text-primary">Voltar ao início</Link></div>});
function RootShell({children}:{children:React.ReactNode}){return <html lang="pt-PT"><head><HeadContent/></head><body>{children}<Scripts/></body></html>}
function RootComponent(){const {queryClient}=Route.useRouteContext();return <QueryClientProvider client={queryClient}><SchoolProvider><Outlet/></SchoolProvider></QueryClientProvider>}
