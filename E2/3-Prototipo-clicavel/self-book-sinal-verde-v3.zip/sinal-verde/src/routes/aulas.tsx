import {createFileRoute} from '@tanstack/react-router';
import {SchoolLayout} from '@/components/SchoolLayout';
import {LessonCalendar} from '@/components/LessonCalendar';
export const Route=createFileRoute('/aulas')({head:()=>({meta:[{title:'Aulas marcadas — Sinal Verde'},{name:'description',content:'Acompanha as tuas aulas de condução e organiza a tua semana com a Sinal Verde.'},{property:'og:title',content:'Aulas marcadas — Sinal Verde'},{property:'og:description',content:'A tua agenda de aulas e o teu percurso até à carta de condução.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]}),component:LessonsPage});
function LessonsPage(){return <SchoolLayout active="lessons"><LessonCalendar booking={false}/></SchoolLayout>}
