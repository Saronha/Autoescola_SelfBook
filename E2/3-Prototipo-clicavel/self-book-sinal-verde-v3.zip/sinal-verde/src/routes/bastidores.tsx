import {useState} from 'react';
import {createFileRoute,Link} from '@tanstack/react-router';
import {LogOut,Plus,Pencil,Trash2,Users,Sun,Sunset,Coffee,CalendarRange,UserRound,ArrowUpDown,Building2,CarFront} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';
import {SchoolBrand} from '@/components/SchoolBrand';
import {useSchool} from '@/components/SchoolContext';
import {SCHOOLS,WEEKDAYS,SHIFTS,INSTRUCTOR_COLORS,STATUS_LABELS,pauseOptions,defaultPause,week,initialsOf,type Instructor,type InstructorStatus,type Shift,type DaySchedule} from '@/lib/lesson-data';

export const Route=createFileRoute('/bastidores')({head:()=>({meta:[{title:'Bastidores — Administração | Sinal Verde'},{name:'description',content:'Área do administrador: gere instrutores e horários de todas as escolas Sinal Verde.'},{property:'og:title',content:'Bastidores — Sinal Verde'},{property:'og:description',content:'Gere instrutores e horários das escolas de condução Sinal Verde.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]}),component:AdminPage});

const h=(n:number)=>`${n}h`;
function shiftText(d:DaySchedule){if(d.shift==='folga')return {title:'Folga',sub:'Dia livre'};const s=SHIFTS[d.shift];return {title:`${h(s.start)} – ${h(s.end)}`,sub:`pausa ${h(d.pause)}–${h(d.pause+1)}`};}
const STATUSES:InstructorStatus[]=['trabalhando','ferias','baixa'];

type SortKey='code'|'name'|'joined'|'school'|'car';
const SORTS:Record<SortKey,string>={code:'Código',name:'Nome',joined:'Data de ingresso',school:'Escola',car:'Carro'};

function AdminPage(){
 const {instructors,addInstructor,removeInstructor,updateInstructor}=useSchool();
 const[view,setView]=useState<'horarios'|'instrutores'>('horarios');
 const[school,setSchool]=useState(SCHOOLS[0]);
 const[sortBy,setSortBy]=useState<SortKey>('code');
 const[editing,setEditing]=useState<Instructor|null>(null);
 const[adding,setAdding]=useState(false);
 const[name,setName]=useState('');const[newShift,setNewShift]=useState<Shift>('manha');const[newSchool,setNewSchool]=useState(SCHOOLS[0]);const[newCar,setNewCar]=useState('');
  const[deleting,setDeleting]=useState<Instructor|null>(null);
  const[picking,setPicking]=useState(false);
 const schoolInstructors=instructors.filter(i=>i.school===school);
 const sorted=[...instructors].sort((a,b)=>String(a[sortBy]).localeCompare(String(b[sortBy])));
 function create(){if(!name.trim())return;const used=new Set(instructors.map(i=>i.color));const color=INSTRUCTOR_COLORS.find(c=>!used.has(c))??INSTRUCTOR_COLORS[instructors.length%INSTRUCTOR_COLORS.length];const code=String(Math.max(0,...instructors.map(i=>Number(i.code)||0))+1).padStart(3,'0');addInstructor({id:`i${Date.now()}`,code,name:name.trim(),initials:initialsOf(name),color,school:newSchool,status:'trabalhando',car:newCar.trim().toUpperCase()||'—',joined:new Date().toISOString().slice(0,10),schedule:week(newShift)});setName('');setNewCar('');setAdding(false);}
 function setDay(idx:number,patch:Partial<DaySchedule>){if(!editing)return;const schedule=editing.schedule.map((d,i)=>{if(i!==idx)return d;const next={...d,...patch};if(patch.shift)next.pause=defaultPause(patch.shift);return next;});setEditing({...editing,schedule});}
 return <div className="school-layout">
  <aside className="sidebar admin-sidebar">
   <Link to="/"><SchoolBrand/></Link>
   <div className="student-profile"><div className="student-avatar"><UserRound size={35}/></div><h2>Admin</h2><p>Nº 0000105</p></div>
   <nav className="space-y-2">
    <button type="button" onClick={()=>setView('horarios')} className={`side-link w-full ${view==='horarios'?'active':''}`}><CalendarRange size={20}/> Gerir horários</button>
    <button type="button" onClick={()=>setView('instrutores')} className={`side-link w-full ${view==='instrutores'?'active':''}`}><Users size={20}/> Ver instrutores</button>
   </nav>
   <div className="mt-auto pt-8"><Button variant="ghost" asChild className="w-full justify-start text-muted-foreground"><Link to="/"><LogOut/> Deslogar</Link></Button></div>
  </aside>
  <main className="school-content">
   <header className="school-topbar"><div className="flex items-center gap-2"><span className="text-sm text-muted-foreground">Administração</span><span className="text-sm font-extrabold">{view==='horarios'?'Gerir horários':'Ver instrutores'}</span></div><span className="traffic-dots"><i/><i/><i/></span></header>

   {view==='horarios'&&<>
    <div className="page-heading"><div><span className="text-primary text-xs font-black uppercase tracking-wider flex items-center gap-1.5"><CalendarRange size={14}/> Gerir horários</span><h1>Horários dos instrutores</h1><p>Escolhe a escola e carrega num dia para mudar o horário.</p></div><Button className="play-button gap-2 px-5" onClick={()=>setPicking(true)}><Plus/> ADICIONAR AO HORÁRIO</Button></div>
    <div className="flex flex-wrap items-center gap-4 mb-6">
     <label className="flex items-center gap-2 text-sm font-extrabold"><Building2 size={18} className="text-primary"/><select aria-label="Escola" value={school} onChange={e=>setSchool(e.target.value)} className="bg-background border-2 border-border rounded-lg py-2 px-3 outline-none focus:border-primary">{SCHOOLS.map(s=><option key={s}>{s}</option>)}</select></label>
     <div className="flex gap-2 ml-auto">
      <span className="shift-legend"><Sun size={16} className="text-yellow"/><b>Manhã</b><small>07h–16h</small></span>
      <span className="shift-legend"><Sunset size={16} className="text-red"/><b>Tarde</b><small>11h–20h</small></span>
     </div>
    </div>
    <div className="overflow-x-auto"><table className="admin-table"><thead><tr><th>Instrutor</th>{WEEKDAYS.map(d=><th key={d}>{d}</th>)}<th className="w-24"><span className="sr-only">Ações</span></th></tr></thead><tbody>
     {schoolInstructors.length===0&&<tr><td colSpan={8} className="text-center py-12 text-muted-foreground">Esta escola ainda não tem instrutores. Adiciona o primeiro!</td></tr>}
     {schoolInstructors.map(i=><tr key={i.id} className={i.color}>
      <td className="pl-4"><div className="flex items-center gap-3"><div className="instructor-avatar">{i.initials}</div><div><span className="font-extrabold text-sm block">{i.name}</span><span className="text-[11px] text-muted-foreground">{STATUS_LABELS[i.status]}</span></div></div></td>
      {i.schedule.map((d,idx)=>{const t=shiftText(d);return <td key={idx}><button type="button" className={`shift-chip ${d.shift}`} onClick={()=>setEditing(i)} aria-label={`Editar ${WEEKDAYS[idx]} de ${i.name}`}>{t.title}<small>{t.sub}</small></button></td>})}
      <td><div className="flex justify-center gap-1"><Button variant="ghost" size="icon" aria-label={`Editar ${i.name}`} onClick={()=>setEditing(i)}><Pencil/></Button><Button variant="ghost" size="icon" className="text-destructive" aria-label={`Remover ${i.name}`} onClick={()=>setDeleting(i)}><Trash2/></Button></div></td>
     </tr>)}
    </tbody></table></div>
    <div className="flex flex-wrap gap-4 mt-4 text-xs text-muted-foreground instructor-gray"><span className="flex items-center gap-1.5"><span className="shift-chip manha !w-4 !h-4 !p-0"/> Manhã (7h–16h)</span><span className="flex items-center gap-1.5"><span className="shift-chip tarde !w-4 !h-4 !p-0"/> Tarde (11h–20h)</span><span className="flex items-center gap-1.5"><Coffee size={14}/> 1 hora de pausa por dia</span></div>
   </>}

   {view==='instrutores'&&<>
    <div className="page-heading"><div><span className="text-primary text-xs font-black uppercase tracking-wider flex items-center gap-1.5"><Users size={14}/> Ver instrutores</span><h1>Instrutores da Sinal Verde</h1><p>Todos os instrutores contratados, de todas as escolas.</p></div><Button className="play-button gap-2 px-5" onClick={()=>setAdding(true)}><Plus/> NOVO INSTRUTOR</Button></div>
    <div className="flex flex-wrap items-center gap-4 mb-5">
     <label className="flex items-center gap-2 text-sm font-extrabold"><ArrowUpDown size={16} className="text-primary"/><select aria-label="Ordenar por" value={sortBy} onChange={e=>setSortBy(e.target.value as SortKey)} className="bg-background border-2 border-border rounded-lg py-2 px-3 outline-none focus:border-primary">{(Object.keys(SORTS) as SortKey[]).map(k=><option key={k} value={k}>{SORTS[k]}</option>)}</select></label>
     <div className="flex gap-2 ml-auto text-xs font-extrabold">
      <span className="status-pill trabalhando">{instructors.filter(i=>i.status==='trabalhando').length} a trabalhar</span>
      <span className="status-pill ferias">{instructors.filter(i=>i.status==='ferias').length} de férias</span>
      <span className="status-pill baixa">{instructors.filter(i=>i.status==='baixa').length} de baixa</span>
     </div>
    </div>
    <div className="overflow-x-auto"><table className="admin-table roster-table"><thead><tr><th>Código</th><th>Nome</th><th>Data de ingresso</th><th>Escola</th><th>Estado</th><th>Carro</th><th className="w-24"><span className="sr-only">Ações</span></th></tr></thead><tbody>
     {sorted.length===0&&<tr><td colSpan={7} className="text-center py-12 text-muted-foreground">Ainda não há instrutores. Adiciona o primeiro!</td></tr>}
     {sorted.map(i=><tr key={i.id} className={i.color}>
      <td className="pl-4 font-extrabold text-sm">{i.code}</td>
      <td><div className="flex items-center gap-3"><div className="instructor-avatar">{i.initials}</div><span className="font-extrabold text-sm">{i.name}</span></div></td>
      <td className="text-sm">{new Date(`${i.joined}T12:00:00`).toLocaleDateString('pt-PT')}</td>
      <td className="text-sm">{i.school}</td>
      <td><span className={`status-pill ${i.status}`}>{STATUS_LABELS[i.status]}</span></td>
      <td className="text-sm font-bold"><span className="inline-flex items-center gap-1.5"><CarFront size={15} className="text-muted-foreground"/>{i.car}</span></td>
      <td><div className="flex justify-center gap-1"><Button variant="ghost" size="icon" aria-label={`Editar ${i.name}`} onClick={()=>setEditing(i)}><Pencil/></Button><Button variant="ghost" size="icon" className="text-destructive" aria-label={`Remover ${i.name}`} onClick={()=>setDeleting(i)}><Trash2/></Button></div></td>
     </tr>)}
    </tbody></table></div>
   </>}

   <p className="text-xs text-muted-foreground mt-6">Ambiente de demonstração: as alterações ficam só nesta sessão.</p>
  </main>

  <Dialog open={adding} onOpenChange={setAdding}><DialogContent className="rounded-2xl max-w-[440px] w-[calc(100%-32px)] p-8 gap-4 shadow-modal"><DialogTitle className="font-display text-3xl font-medium">Novo instrutor</DialogTitle><DialogDescription>Escolhe o nome, a escola e o turno. Podes afinar cada dia depois.</DialogDescription>
   <label className="text-sm font-extrabold">Nome<input autoFocus value={name} onChange={e=>setName(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')create()}} placeholder="Ex.: Eva Estrada" className="mt-1.5 w-full bg-background border-2 border-border rounded-xl py-2.5 px-3 outline-none focus:border-primary font-normal"/></label>
   <label className="text-sm font-extrabold">Carro (matrícula)<input value={newCar} onChange={e=>setNewCar(e.target.value)} placeholder="AA-00-00" className="mt-1.5 w-full bg-background border-2 border-border rounded-xl py-2.5 px-3 outline-none focus:border-primary font-normal"/></label>
   <label className="text-sm font-extrabold">Escola<select value={newSchool} onChange={e=>setNewSchool(e.target.value)} className="mt-1.5 w-full bg-background border-2 border-border rounded-xl py-2.5 px-3 outline-none focus:border-primary font-normal">{SCHOOLS.map(s=><option key={s}>{s}</option>)}</select></label>
   <div className="grid grid-cols-2 gap-2">{(['manha','tarde'] as const).map(s=><button key={s} type="button" onClick={()=>setNewShift(s)} className={`rounded-xl border-2 p-3 text-left ${newShift===s?'border-primary bg-accent':'border-border'}`}>{s==='manha'?<Sun size={18} className="text-yellow"/>:<Sunset size={18} className="text-red"/>}<p className="font-extrabold text-sm mt-1">{SHIFTS[s].label}</p><p className="text-xs text-muted-foreground">{h(SHIFTS[s].start)} – {h(SHIFTS[s].end)}</p></button>)}</div>
   <Button className="play-button w-full" disabled={!name.trim()} onClick={create}>ADICIONAR <Plus/></Button>
  </DialogContent></Dialog>

  <Dialog open={editing!==null} onOpenChange={o=>{if(!o)setEditing(null)}}><DialogContent className="rounded-2xl max-w-[560px] w-[calc(100%-32px)] p-6 sm:p-8 gap-4 shadow-modal max-h-[90svh] overflow-y-auto">{editing&&<>
   <div className={`flex items-center gap-3 ${editing.color}`}><div className="instructor-avatar !w-12 !h-12">{editing.initials}</div><div><DialogTitle className="font-display text-2xl font-medium">{editing.name}</DialogTitle><DialogDescription>Define o turno e a pausa de cada dia.</DialogDescription></div></div>
   <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
    <label className="text-sm font-extrabold">Escola<select value={editing.school} onChange={e=>setEditing({...editing,school:e.target.value})} className="mt-1.5 w-full bg-background border-2 border-border rounded-xl py-2 px-3 outline-none focus:border-primary font-normal">{SCHOOLS.map(s=><option key={s}>{s}</option>)}</select></label>
    <label className="text-sm font-extrabold">Estado<select value={editing.status} onChange={e=>setEditing({...editing,status:e.target.value as InstructorStatus})} className="mt-1.5 w-full bg-background border-2 border-border rounded-xl py-2 px-3 outline-none focus:border-primary font-normal">{STATUSES.map(s=><option key={s} value={s}>{STATUS_LABELS[s]}</option>)}</select></label>
    <label className="text-sm font-extrabold sm:col-span-2">Carro (matrícula)<input value={editing.car} onChange={e=>setEditing({...editing,car:e.target.value.toUpperCase()})} placeholder="AA-00-00" className="mt-1.5 w-full bg-background border-2 border-border rounded-xl py-2.5 px-3 outline-none focus:border-primary font-normal"/></label>
   </div>
   <div className="space-y-2">{editing.schedule.map((d,idx)=><div key={idx} className="flex flex-wrap items-center gap-2 border-2 border-border rounded-xl p-2.5"><span className="w-20 font-extrabold text-sm">{WEEKDAYS[idx]}</span>
    <div className="flex gap-1">{(['manha','tarde','folga'] as const).map(s=><Button key={s} size="sm" variant={d.shift===s?'default':'outline'} className="rounded-lg text-xs" onClick={()=>setDay(idx,{shift:s})}>{s==='folga'?'Folga':`${h(SHIFTS[s].start)}–${h(SHIFTS[s].end)}`}</Button>)}</div>
    {d.shift!=='folga'&&<label className="flex items-center gap-1 text-xs text-muted-foreground ml-auto"><Coffee size={14}/><select aria-label={`Pausa de ${WEEKDAYS[idx]}`} value={d.pause} onChange={e=>setDay(idx,{pause:Number(e.target.value)})} className="bg-background border-2 border-border rounded-lg py-1 px-2 text-foreground font-bold">{pauseOptions(d.shift).map(p=><option key={p} value={p}>{h(p)}–{h(p+1)}</option>)}</select></label>}
   </div>)}</div>
   <div className="flex gap-2"><Button variant="ghost" className="flex-1" onClick={()=>setEditing(null)}>Cancelar</Button><Button className="play-button flex-1" onClick={()=>{updateInstructor(editing);setEditing(null)}}>GUARDAR</Button></div>
  </>}</DialogContent></Dialog>

  <Dialog open={deleting!==null} onOpenChange={o=>{if(!o)setDeleting(null)}}><DialogContent className="rounded-2xl max-w-[420px] w-[calc(100%-32px)] p-8 gap-4 text-center shadow-modal"><div className="mx-auto w-16 h-16 rounded-2xl bg-muted text-destructive grid place-items-center"><Trash2 size={30}/></div><DialogTitle className="font-display text-2xl font-medium">Remover {deleting?.name}?</DialogTitle><DialogDescription>Deixa de aparecer na marcação de aulas.</DialogDescription><Button variant="destructive" className="w-full h-11 rounded-xl font-extrabold" onClick={()=>{if(deleting)removeInstructor(deleting.id);setDeleting(null)}}>Sim, remover</Button><Button variant="ghost" onClick={()=>setDeleting(null)}>Voltar</Button></DialogContent></Dialog>

  <Dialog open={picking} onOpenChange={setPicking}><DialogContent className="rounded-2xl max-w-[460px] w-[calc(100%-32px)] p-8 gap-4 shadow-modal max-h-[90svh] overflow-y-auto"><DialogTitle className="font-display text-3xl font-medium">Adicionar ao horário</DialogTitle><DialogDescription>Escolhe um instrutor da equipa para passar a trabalhar em {school}.</DialogDescription>
   {instructors.filter(i=>i.school!==school).length===0&&<p className="text-sm text-muted-foreground text-center py-6">Todos os instrutores já estão nesta escola. Cria novos em "Ver instrutores".</p>}
   <div className="space-y-2">{instructors.filter(i=>i.school!==school).map(i=><button key={i.id} type="button" onClick={()=>{updateInstructor({...i,school});setPicking(false)}} className={`w-full flex items-center gap-3 rounded-xl border-2 border-border p-3 text-left hover:border-primary ${i.color}`}><div className="instructor-avatar">{i.initials}</div><div className="flex-1"><span className="font-extrabold text-sm block">{i.name}</span><span className="text-xs text-muted-foreground">{i.code} · atualmente em {i.school} · {STATUS_LABELS[i.status]}</span></div><Plus size={18} className="text-primary"/></button>)}</div>
  </DialogContent></Dialog>
 </div>;
}
