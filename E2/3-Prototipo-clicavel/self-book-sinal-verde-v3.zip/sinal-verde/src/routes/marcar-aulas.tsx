import {createFileRoute} from '@tanstack/react-router';
import {SchoolLayout} from '@/components/SchoolLayout';
import {LessonCalendar} from '@/components/LessonCalendar';
export const Route=createFileRoute('/marcar-aulas')({head:()=>({meta:[{title:'Marcar aulas — Sinal Verde'},{name:'description',content:'Escolhe o instrutor e o horário para a tua próxima aula de condução na Sinal Verde.'},{property:'og:title',content:'Marcar aulas — Sinal Verde'},{property:'og:description',content:'O teu próximo passo ao volante. Consulta os horários e organiza as tuas aulas.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]}),component:BookingPage});
function BookingPage(){return <SchoolLayout active="book"><LessonCalendar booking/></SchoolLayout>}
